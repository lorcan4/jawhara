<!-- footer1-->
<footer class="footer1">
  <div class="container123">
    <div class="footer_inner">
      <div class="footer_content" >
        <div class="layout" >
          <div class="layout_item w-0">
            <div class="newsletter">
              <h3 class="newsletter_title" data-aos="fade-right">Get updates on fun stuff you probably want to know about in your inbox.</h3>
             <br>
            </div>
          </div>
          <div class="layout_item w-15" >
            <nav class="nav_tool">
              <h4 class="nav_tool_title">Menu</h4>
              <ul class="nav_tool_list">
                <li>
                  <a href="./home.php" class="nav_link">Accueil</a>
                </li>

                <li>
                  <a href="/who-we-are.php" class="nav_link">About Us</a>
                </li>

                <li>
                  <a href="https://www.instagram.com/aissaagaouiri?igsh=ejR1NTRoazVsdXE0" class="nav_link">Instargram</a>
                </li>
               
              </ul>
            </nav>
          </div>
          <div class="layout_item w-25">
            <nav class="nav_tool">
              <h4 class="nav_tool_title">Support</h4>
              <ul class="nav_tool_list">

                

                <li class="nav_tool_item">
                  <a href="./contact.php" class="nav_link">Help &amp; FAQ</a>
                </li>

                <li class="nav_tool_item">
                  <a href="./contact.php" class="nav_link">Terms &amp; Conditions</a>
                </li>

                <li class="nav_tool_item">
                  <a href="https://wa.me/+2120654393672" class="nav_link">WhatsApp</a>
                </li>

                <li class="nav_tool_item">
                  <a href="./contact.php" class="nav_link">Contact</a>
                </li>

               
                </li>
              </ul>
            </nav>

          </div>
        </div>
        <div class="layout footer_icons">
          <div class="layout_item w-50">          
            <img src="logo2.png" alt="" width="120px">                       
          </div>
        </div>
      </div>
    </div>
  </div>  
</footer>
<!-- footer1-->
<br>
<!-- jawhara-->
<div class="d-flex justify-content-center">
  <div class="text-center">
    <h1 class="sool" data-aos="zoom-in"data-aos-delay="500">votre meilleure décision !</h1><br>
    
  <div class="wrapper">
    <div class="jawhara">
      <h1 id="kool" data-aos="zoom-in"data-aos-delay="500">Jawhara</h1>
    </div>
  </div>
<!-- jawhara-->
<!-- footer-->
<footer class="footer1">
  <div class="container">
    <span>&copy; 2024 My Website. All rights reserved. Lorcan / Aissa Agaouiri</span>
  </div>
</footer>
<!-- footer-->