// Scroll 1
 function scrollToPosition1() {
    window.scrollTo({
      top: 600,
      behavior: 'smooth'
    });
  }  
  


   